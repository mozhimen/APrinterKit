package cc.liyongzhi.bluetoothselector.exceptions;

/**
 * Created by lee on 5/23/16.
 */
public class BluetoothNotSupportException extends Exception {

    public BluetoothNotSupportException(String msg) {
        super(msg);
    }

}
