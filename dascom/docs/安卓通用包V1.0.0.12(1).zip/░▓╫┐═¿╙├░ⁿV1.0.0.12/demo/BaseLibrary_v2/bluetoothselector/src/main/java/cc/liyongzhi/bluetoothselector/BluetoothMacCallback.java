package cc.liyongzhi.bluetoothselector;

public abstract class BluetoothMacCallback {

    public abstract String getMac(String mac);

}
