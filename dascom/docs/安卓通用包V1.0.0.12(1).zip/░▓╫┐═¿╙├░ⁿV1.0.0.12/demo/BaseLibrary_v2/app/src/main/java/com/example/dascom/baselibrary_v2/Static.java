package com.example.dascom.baselibrary_v2;

/*
 * Copyright (c) 2020 DASCOM All rights reserved.
 */


public class Static {

    public static String emulation = "ZPL";
    public final static String[] emulations = {"ZPL", "TSPL", "ESCP", "ESCPOS", "ESCPOS_9Pin", "EPL", "OKI", "CPCL"};
    public final static String Dascom = "http://www.dascom.cn/front/web/";
}
